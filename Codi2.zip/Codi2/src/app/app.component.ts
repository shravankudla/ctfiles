import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  

}









































Value Provider Component:

import { Component, EventEmitter, Output } from '@angular/core';

@Component({
selector: 'app-value-provider',
template: <input type="text" (input)="onInput($event.target.value)" /> })
export class ValueProviderComponent {
@Output() typedValue = new EventEmitter<string>();

onInput(value: string) {
this.typedValue.emit(value);
}
}

Value Receiver Component:

import { Component, Input } from '@angular/core';

@Component({
selector: 'app-value-receiver',
template: <p>{{ printValue }}</p> })
export class ValueReceiverComponent {
@Input() printValue: string;
}

App Component:

import { Component } from '@angular/core';

@Component({
selector: 'app-root',
template: <app-value-provider (typedValue)="onTypedValue($event)"></app-value-provider> <app-value-receiver [printValue]="receivedValue"></app-value-receiver> })
export class AppComponent {
receivedValue = '';

onTypedValue(value: string) {
console.log('Typed value:', value);
this.receivedValue = value;
}
}
