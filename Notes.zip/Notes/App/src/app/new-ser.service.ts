import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class NewSerService {

  constructor( private http:HttpClient) { }
  getUserData(){
    return this.http.get('http://localhost:3000/employees');
  }

  getplaceHolderData(){
    return this.http.get('https://jsonplaceholder.typicode.com/users');
  }
  
  addProduct(input:any){
    return this.http.post('http://localhost:3000/employees',input);
  }

  deleteProduct(input:any){
    return this.http.delete('http://localhost:3000/employees/'+input);
  }
  
  updateProduct(input:any,updates:any){
    return this.http.put('http://localhost:3000/employees/'+input+'',updates);
  }

}
