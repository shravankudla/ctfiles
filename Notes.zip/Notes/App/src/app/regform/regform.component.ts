import { Component } from '@angular/core';
import { NewSerService } from '../new-ser.service';

@Component({
  selector: 'app-regform',
  templateUrl: './regform.component.html',
  styleUrls: ['./regform.component.css']
})
export class RegformComponent {
  constructor(private service:NewSerService){}
  submit(data:any){
    console.log(data.value);
    const studInput={
      "name":data.value.fname,
      "age":data.value.age,
      "address":data.value.address,
      "phone":data.value.phone
    }
    this.service.addProduct(studInput).subscribe(result=>{
      console.log(result);
    })
    // this.data=data.value;
  }
}
