import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NoteformComponent } from './noteform/noteform.component';
import { DeleteformComponent } from './deleteform/deleteform.component';
import { EditformComponent } from './editform/editform.component';
import { NewnoteComponent } from './newnote/newnote.component';

const routes: Routes = [
  {path:'',component:NoteformComponent},
  {path:'edit',component:EditformComponent},
  {path:'delete',component:DeleteformComponent},
  {path:'new',component:NewnoteComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
