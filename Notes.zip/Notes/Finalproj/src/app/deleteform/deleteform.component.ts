import { Component } from '@angular/core';

@Component({
  selector: 'app-deleteform',
  templateUrl: './deleteform.component.html',
  styleUrls: ['./deleteform.component.css']
})
export class DeleteformComponent {

}
