import { Component } from '@angular/core';
import { NewserService } from '../newser.service';

@Component({
  selector: 'app-newnote',
  templateUrl: './newnote.component.html',
  styleUrls: ['./newnote.component.css']
})
export class NewnoteComponent {
  constructor(private serv:NewserService){}
  n:any;
  newnote(data:any){
    console.log(data.value)
    const add={
      "title":data.title,
      "content":data.content
    }
    this.serv.newNotes(add).subscribe(udata=>{
      console.log(udata)
    })
  }
}
