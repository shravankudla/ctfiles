import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NoteformComponent } from './noteform/noteform.component';
import {HttpClientModule} from '@angular/common/http';
import { EditformComponent } from './editform/editform.component';
import { DeleteformComponent } from './deleteform/deleteform.component';
import { NewnoteComponent } from './newnote/newnote.component'


@NgModule({
  declarations: [
    AppComponent,
    NoteformComponent,
    EditformComponent,
    DeleteformComponent,
    NewnoteComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
