import { Component } from '@angular/core';
import { NewserService } from '../newser.service';

@Component({
  selector: 'app-noteform',
  templateUrl: './noteform.component.html',
  styleUrls: ['./noteform.component.css']
})
export class NoteformComponent {
  note:any;
  constructor(private noteservice:NewserService)
  {
    let data=this.noteservice.getNotes().subscribe(udata=>{
      console.log(udata)
      this.note=udata;
    });
  }
}
