import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NewserService {

  constructor(private http:HttpClient) { }
  getNotes(){
    return this.http.get('http://localhost:3000/notes');
  }
  newNotes(input:any){
    return this.http.post('http://localhost:3000/notes',input);
  }
}
