import { TestBed } from '@angular/core/testing';

import { NewserService } from './newser.service';

describe('NewserService', () => {
  let service: NewserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NewserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
