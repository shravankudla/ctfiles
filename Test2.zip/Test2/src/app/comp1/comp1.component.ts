import { Component,Input } from '@angular/core';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component {
  @Input() Send:any;
  titleOfComp='My Application'
  imgsrc='/assets/image/im.png'
  count=0
  name: string|undefined
  inc()
  {
    this.count+=1;
  }
  myFunc(val:string){
    this.name=val
    if(this.name=="shravan")
    {
      alert("You are an authorized person")
    }
  }
}
