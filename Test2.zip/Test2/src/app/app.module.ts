import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Comp1Component } from './comp1/comp1.component';
import {FormsModule} from '@angular/forms';
import { NewchildComponent } from './newchild/newchild.component';
import { EmployeeinfoComponent } from './employeeinfo/employeeinfo.component';
import { DisplayEmployeeDetailsComponent } from './display-employee-details/display-employee-details.component';
import { ChangecolorDirective } from './changecolor.directive';
import { StrpipPipe } from './strpip.pipe';
import { RegformComponent } from './regform/regform.component'

@NgModule({
  declarations: [
    AppComponent,
    Comp1Component,
    NewchildComponent,
    EmployeeinfoComponent,
    DisplayEmployeeDetailsComponent,
    ChangecolorDirective,
    StrpipPipe,
    RegformComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
