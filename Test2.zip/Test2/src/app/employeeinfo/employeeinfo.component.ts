import { Component,OnInit } from '@angular/core';
import { employee } from '../services/employee.services';

@Component({
  selector: 'app-employeeinfo',
  templateUrl: './employeeinfo.component.html',
  styleUrls: ['./employeeinfo.component.css']
})
export class EmployeeinfoComponent implements OnInit{

  constructor(private employees:employee)
  {

  }
  empdata:{ename:string, dept:string,gender:string,age:number,location:string,email:string}[]=[];

  ngOnInit():void{
    this.empdata=this.employees.employees;
  }

  showDetails(emp:{ename:string,dept:string,gender:string,age:number,location:string,email:string})
  {
    this.employees.showEmpDetails(emp);
  }

}
