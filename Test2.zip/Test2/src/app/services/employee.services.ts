import { EventEmitter } from "@angular/core"
export class employee{ 
    employees=[
    {ename:'John', dept:'HR',gender:'Male',age:35,location:'Chennai',email:'john@gmail.com'},        
    {ename:'James', dept:'IT',gender:'Male',age:38,location:'Delhi',email:'john@gmail.com'},        
    {ename:'Kevin', dept:'Admin',gender:'Male',age:32,location:'Mumbai',email:'john@gmail.com'},        
    {ename:'Tom', dept:'Finance',gender:'Male',age:40,location:'Pune',email:'john@gmail.com'}]
        
    OnEmpDetailsClicked=new EventEmitter<{ename:string,dept:string,gender:string,age:number,location:string,email:string}>();
    showEmpDetails(emp:{ename:string,dept:string,gender:string,age:number,location:string,email:string}){
        this.OnEmpDetailsClicked.emit(emp);
    }
}
