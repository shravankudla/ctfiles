import { StrpipPipe } from './strpip.pipe';

describe('StrpipPipe', () => {
  it('create an instance', () => {
    const pipe = new StrpipPipe();
    expect(pipe).toBeTruthy();
  });
});
