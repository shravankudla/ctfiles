import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appChangecolor]'
})
export class ChangecolorDirective {

  constructor(private element:ElementRef) 
  {
    this.element.nativeElement.style.color='blue';
    this.element.nativeElement.style.background='pink'
  }

}
