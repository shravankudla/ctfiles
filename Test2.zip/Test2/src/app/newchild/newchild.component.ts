import { Component, EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-newchild',
  templateUrl: './newchild.component.html',
  styleUrls: ['./newchild.component.css']
})
export class NewchildComponent {
  @Output() ParentFunct:EventEmitter<any>=new EventEmitter();

  sendDataParent(){
    let data={ename:'Bhushan',age:25}
    this.ParentFunct.emit(data)
  }
}
