import {employee} from './services/employee.services'
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[employee]
})
export class AppComponent {
  title = 'Test2';
  constructor(private employees:employee)
  {

  }
  choice=''

  dataToSend="Hello From Daddy"

  iage=0;
  iname=''
  ParentFunc(data:any){
    this.iage=data.age;
    this.iname=data.ename;
  }
  courses=[{courseid:1,coursename:'Python',Duration:'3 Months'},
           {courseid:2,coursename:'Java',Duration:'4 Months'},
           {courseid:3,coursename:'C#',Duration:'1 Month'}]
  // name=''
  // id=0
  // dur=''
  addcourse(){
    this.courses.push({courseid:4,coursename:'Ruby',Duration:'20 days'});
  }
  // addcourse(nam:string,i:number,du:string)
  // {
  //   this.courses.push({courseid:i,coursename:nam,Duration:du})
  // }
  myStyle={
    width:'200px',
    height:'50px',
    background:'hotpink',
    color:'black'
  }
  myClass={
    box: true,
    border: false,
    circle: false
  }
  change(){
    this.myClass.border=true,
    this.myClass.circle=true
    }
  arr=['suksham','bhushan','ashwitha','sandeep']
  addemp(value:any){
    this.arr.push(value);
    console.log(this.arr);
  }
}
