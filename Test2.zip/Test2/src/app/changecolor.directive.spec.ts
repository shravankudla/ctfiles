import { ChangecolorDirective } from './changecolor.directive';

describe('ChangecolorDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangecolorDirective();
    expect(directive).toBeTruthy();
  });
});
