import { Component, OnInit} from '@angular/core';
import { employee } from '../services/employee.services';

@Component({
  selector: 'app-display-employee-details',
  templateUrl: './display-employee-details.component.html',
  styleUrls: ['./display-employee-details.component.css']
})
export class DisplayEmployeeDetailsComponent implements OnInit {

  constructor(private employees:employee)
  {

  }
  empd!:{ename:string, dept:string,gender:string,age:number,location:string,email:string};
  ngOnInit(){
    this.employees.OnEmpDetailsClicked.subscribe((data:{ename:string, dept:string,gender:string,age:number,location:string,email:string})=>{
      this.empd=data;
    })
  }
}
