import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import {addTwoNumber,multiplication,divisionOfTwo,substraction} from '../calculations'

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });

  // it('should create the app', () => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   const app = fixture.componentInstance;
  //   expect(app).toBeTruthy();
  // });

  // it(`should have as title 'NewApp'`, () => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   const app = fixture.componentInstance;
  //   expect(app.title).toEqual('NewApp');
  // });

  // it('should render title', () => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   fixture.detectChanges();
  //   const compiled = fixture.nativeElement as HTMLElement;
  //   expect(compiled.querySelector('.content span')?.textContent).toContain('NewApp app is running!');
  // });
  it('Addition',()=>{
    expect(30).toBe(addTwoNumber(10,20))
  })
  it('Substract',()=>{
    expect(30).toBe(substraction(50,20))
  })
  it('Divide',()=>{
    expect(30).toBe(divisionOfTwo(600,20))
  })
  it('Addition',()=>{
    expect(30).toBe(multiplication(1.5,20))
  })
  let obj=new AppComponent();
  it('AppAdd',()=>{
    expect(12).toBe(obj.addTwoNumber(6,6));
  })

  it('equalizeTo',()=>{
    let name1=['hello']
    let name2=['hello']
    expect(name1[0]).toBe(name2[0])
  })
});
