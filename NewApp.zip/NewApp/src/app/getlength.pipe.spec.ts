import { GetlengthPipe } from './getlength.pipe';

describe('GetlengthPipe', () => {
  it('create an instance', () => {
    const pipe = new GetlengthPipe();
    expect(pipe).toBeTruthy();
  });
});
