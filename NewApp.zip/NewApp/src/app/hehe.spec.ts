import { TestBed } from "@angular/core/testing";
import { AppComponent } from "./app.component";
import{addTwoNumber,substraction,divisionOfTwo} from '../calculations'
import { GetlengthPipe } from "./getlength.pipe";

describe('AppComponent',()=>{
    
    // beforeAll(()=>{
    //     console.log('Before All Called')
    // })

    beforeEach(()=>{
        console.log('Before Each Called')
    })

    it('myFirstTest',()=>{
        expect(20).toBe(addTwoNumber(10,10));
        expect(20).toBe(substraction(80,60));
    })

    it('mySecondTest',()=>{
        expect(50).toBe(addTwoNumber(30,20));
        expect(69).toBe(substraction(90,21));
    })

    afterEach(()=>{
        console.log('After Each Called')
    })

    let length=new GetlengthPipe();
    it('testing getlength pipe',()=>{
        expect(7).toBe(length.transform('Bhushan'));
    })

    it('not to be',()=>{
        expect(3).not.toBe(addTwoNumber(1,3))
    })
})