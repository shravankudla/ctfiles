import { Component } from '@angular/core';

@Component({
  selector: 'app-newcomp',
  templateUrl: './newcomp.component.html',
  styleUrls: ['./newcomp.component.css']
})
export class NewcompComponent {
  getFullName(fname:string,lname:string):string{
    return fname+lname;
  }

  logFullName(){
    let fullname=this.getFullName('shravan','kudla');
    let fullnam=this.getFullName('shravan','kudla');

  }
}
