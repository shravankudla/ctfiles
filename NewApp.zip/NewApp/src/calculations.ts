function addTwoNumber(num1:number,num2:number):number{
    return num1+num2;
}
function divisionOfTwo(num1:number,num2:number):number{
    return num1/num2;
}
function multiplication(num1:number,num2:number):number{
    return num1*num2;
}
function substraction(num1:number,num2:number):number{
    return num1-num2;
}

export{addTwoNumber,multiplication,divisionOfTwo,substraction}