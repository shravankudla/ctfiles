import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegformComponent } from './regform/regform.component'; 
import { SiginComponent } from './sigin/sigin.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HomeComponent } from './home/home.component';
import { UsersComponent } from './users/users.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { PrimeComponent } from './users/prime/prime.component';
import { AuthGuard } from './auth.guard';
import { UnsavedchangesGuard } from './unsavedchanges.guard';
import { AddstudentComponent } from './addstudent/addstudent.component';
import { UpdatestudentComponent } from './updatestudent/updatestudent.component';
import { DeletestudentComponent } from './deletestudent/deletestudent.component';

const routes: Routes = [
  {path:'', component:HomeComponent},
  {path:'home', component:HomeComponent},
  {path: 'regform', component:RegformComponent, canDeactivate:[UnsavedchangesGuard]},
  {path: 'sign', component:SiginComponent,canActivate:[AuthGuard]},
  {path:'about', component:PagenotfoundComponent},
  {path:'add', component:AddstudentComponent},
  {path:'update',component:UpdatestudentComponent},
  {path:'delete',component:DeletestudentComponent},
  {path:'lazymodule', loadChildren:()=>import('./lazymodule/lazymodule.module').
  then(mod=>mod.LazymoduleModule)},
  {path:'user', children:[
    {path:'',component:UsersComponent},
    {path:'prime',component:PrimeComponent}
  ]
  },
  {path:'userdet/:id/:name/:address', component:UserdetailsComponent},
  {path: '**' ,component:PagenotfoundComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
