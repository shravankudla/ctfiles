import { Component } from '@angular/core';
import { StudentserviceService } from '../studentservice.service';

@Component({
  selector: 'app-updatestudent',
  templateUrl: './updatestudent.component.html',
  styleUrls: ['./updatestudent.component.css']
})
export class UpdatestudentComponent {
  constructor(private student:StudentserviceService){}
  sname!: string;
  sid!:number
  submit(reg:any) {
    console.log(reg.value.sname)
    const studentInput = {
      "sname": reg.value.sname,
      "saddress": reg.value.saddress,
      "sage": Number(reg.value.sage),
      "phone": reg.value.phone
    }
    this.sname=reg.value.sname
    this.sid=reg.value.sid
    this.student.updateStudent(studentInput,this.sid).subscribe(result => {
      console.log(result)
      
    });
  }
  get sname1(){
    return this.sname
  }

}
