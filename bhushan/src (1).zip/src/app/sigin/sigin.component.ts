import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms'

@Component({
  selector: 'app-sigin',
  templateUrl: './sigin.component.html',
  styleUrls: ['./sigin.component.css']
})
export class SiginComponent {
  signinform = new FormGroup({
    un:new FormControl('',[Validators.required]),
    ps:new FormControl('',[Validators.minLength(3),Validators.maxLength(8),Validators.required])
  });

  signIn(){
    console.log(this.signinform.value)
  }

  get un(){
    return this.signinform.get('un');
  }

  get ps(){
    return this.signinform.get('ps');
  }
}
