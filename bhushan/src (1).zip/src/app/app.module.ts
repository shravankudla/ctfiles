import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegformComponent } from './regform/regform.component';
import { SiginComponent } from './sigin/sigin.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { UsersComponent } from './users/users.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { PrimeComponent } from './users/prime/prime.component'; 
import { AuthGuard } from './auth.guard';
import { UnsavedchangesGuard } from './unsavedchanges.guard';
import { AddstudentComponent } from './addstudent/addstudent.component';
import { UpdatestudentComponent } from './updatestudent/updatestudent.component';
import { DeletestudentComponent } from './deletestudent/deletestudent.component';


@NgModule({
  declarations: [
    AppComponent,
    RegformComponent,
    SiginComponent,
    PagenotfoundComponent,
    HomeComponent,
    UsersComponent,
    UserdetailsComponent,
    PrimeComponent,
    AddstudentComponent,
    UpdatestudentComponent,
    DeletestudentComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    
  ],
  providers: [AuthGuard, UnsavedchangesGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
