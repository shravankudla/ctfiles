import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StudentserviceService {

  constructor(private http:HttpClient) { }
  getStudentData(){
    return this.http.get("http://localhost:8080/api/student");
  }

  addStudent(input:any){
    return this.http.post("http://localhost:8080/api/student",input)
  }

  updateStudent(input:any,id:number){
    return this.http.put("http://localhost:8080/api/student/"+id,input);

  }

  deleteStudent(id:number){
    return this.http.delete("http://localhost:8080/api/student/"+id);
  }
  
}
