import { Component } from '@angular/core';
import { StudentserviceService } from '../studentservice.service';

@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent {
  constructor(private student: StudentserviceService) { }
  sname!: string;
  submit(reg:any) {
    console.log(reg.value.sname)
    const studentInput = {
      "sname": reg.value.sname,
      "saddress": reg.value.saddress,
      "sage": Number(reg.value.sage),
      "phone": reg.value.phone
    }
    this.sname=reg.value.sname
    this.student.addStudent(studentInput).subscribe(result => {
      console.log(result)
      
    });
  }
  get sname1(){
    return this.sname
  }


}
