import { Component } from '@angular/core';
import { StudentserviceService } from '../studentservice.service';

@Component({
  selector: 'app-deletestudent',
  templateUrl: './deletestudent.component.html',
  styleUrls: ['./deletestudent.component.css']
})
export class DeletestudentComponent {

  constructor(private student: StudentserviceService) { }
  sid!: number;
  submit(reg:any) {
    console.log(reg.value.sname)
    this.sid=reg.value.sid
    this.student.deleteStudent(this.sid).subscribe(result => {
      console.log(result)
      
    });
  }
  get sid1(){
    return this.sid
  }

}
