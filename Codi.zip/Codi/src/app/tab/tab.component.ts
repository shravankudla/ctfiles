import { Component, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { debounceTime, distinctUntilChanged, filter, switchMap } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-tab',
  template: `
    <div class="wrapper">
      <div class="control">
        <input type="text" class="input" placeholder="Type to search..." [(ngModel)]="query">
      </div>
      <div class="list" *ngIf="items">
        <a class="list-item" *ngFor="let item of items" (click)="selectItem(item)">{{ item }}</a>
      </div>
    </div>
  `
})
export class TabComponent {
  @Output() onselect: EventEmitter<string> = new EventEmitter<string>();
  query: string = '';
  items: string[]=[];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    const input$ = new Observable<string>((observer) => {
      const input = document.querySelector('.input') as HTMLInputElement;
      input.addEventListener('input', (e: any) => observer.next(e.target.value));
    });

    input$
      .pipe(
        filter((query) => query.length > 0),
        debounceTime(500),
        distinctUntilChanged(),
        switchMap((query) => this.http.get<string[]>(`https://example.com/api/items?q=${query}`))
      )
      .subscribe((items) => {
        this.items = items;
        const wrapper = document.querySelector('.wrapper') as HTMLElement;
        wrapper.classList.remove('is-loading');
      }, (error) => {
        console.error(error);
        const wrapper = document.querySelector('.wrapper') as HTMLElement;
        wrapper.classList.remove('is-loading');
      });
  }

  selectItem(item: string) {
    this.onselect.emit(item);
  }
}