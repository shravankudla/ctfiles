import { Component } from '@angular/core';

@Component({
  selector: 'app-tab-group',
  templateUrl: './tab-group.component.html',
  styleUrls: ['./tab-group.component.css']
})
export class TabGroupComponent {
  dataToTabComp:any
  Tabs=[
    {
      title:"Section 1",
      Content:"Section 1 Content is here hehehhehehhhehh dhjjdjd hh"
    },
    {
      title:"Section 2",
      Content:"Section 2 Content is here"
    }
  ]
  clicked:boolean=false
  status:boolean=true
  openCity(data:any,dat:any){
    this.status=!this.status
    this.dataToTabComp=dat
    console.log(this.dataToTabComp)
  }
  inx:any
  cli(event:any){
    this.inx=event
  }
}
