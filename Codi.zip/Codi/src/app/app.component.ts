import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Codi';
  
  menu=[{
    name:"Computer",
    subitems:["Website","Url","Browser"],
    Expanded:false
  },{
    name:"Mobile",
    subitems:["Apps","Android"],
    Expanded:false
  },{
    name:"Tablet",
    subitems:["Games","IPad"],
    Expanded:false
  }]

  exp(data:any){
    // this.idata=data;
    // if(this.btn=="Expand")
    // {
    //   this.btn="Hide"
    // }
    // else{this.btn="Expand"}
    // this.isdone=!this.isdone
    // this.num=n
    this.menu.forEach(e => {
      if(e.name!=data.name)
      e.Expanded=false
    });
    data.Expanded=!data.Expanded
  }
  onBodyClick() {
    this.menu.forEach(men => {
      men.Expanded = false;
    });
  }
}
