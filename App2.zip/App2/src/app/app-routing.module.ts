import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegFormComponent } from './reg-form/reg-form.component';
import { SigninComponent } from './signin/signin.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HomeComponent } from './home/home.component';
import { UpdatecomponentComponent } from './updatecomponent/updatecomponent.component';
import { UsersComponent } from './users/users.component';
import { PrimeuserComponent } from './users/primeuser/primeuser.component';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'regform',component:RegFormComponent},
  {path:'signin',component:SigninComponent},
  {path:'update',component:UpdatecomponentComponent},
  {path:'user',
  children:[{path:'',component:UsersComponent},
            {path:'prime',component:PrimeuserComponent}]},
  {path:'lazymodule' ,loadChildren:()=>import('./lazymodule/lazymodule.module').then(m=>m.LazymoduleModule)},
  {path:'**',component:PagenotfoundComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
