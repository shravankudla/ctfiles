import { Component } from '@angular/core';

@Component({
  selector: 'app-pagenotfound',
  template: '<h1 style="color:red">Page Not found</h1>',
  styleUrls: ['./pagenotfound.component.css']
})
export class PagenotfoundComponent {

}
