import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserserService {

  constructor(private Http:HttpClient) { }
    get(){
      return this.Http.get('https://localhost:44379/api/Contact');
    }
    getplaceHolderData(){
      return this.Http.get('https://jsonplaceholder.typicode.com/users');
    }
    add(val:any){
      return this.Http.post('https://localhost:44379/api/Contact',val);
    }
    edit(id:any,val:any){
      return this.Http.put('https://localhost:44379/api/Contact/'+id+'',val);
    }
    delet(id:any){
      return this.Http.delete('https://localhost:44379/api/Contact/'+id);
    }
}
