import { Component } from '@angular/core';
import { UserserService } from '../userser.service';

@Component({
  selector: 'app-updatecomponent',
  templateUrl: './updatecomponent.component.html',
  styleUrls: ['./updatecomponent.component.css']
})
export class UpdatecomponentComponent {
  constructor(private user:UserserService){}
  update(data:any){
    let stid=data.value.cno
    
    const updates={
      "ContactName":data.value.fname,
      "City":data.value.address,
      "CellNo":data.value.phone
    }

    this.user.edit(stid,updates).subscribe(udata=>{console.log(udata)})
  }
}
