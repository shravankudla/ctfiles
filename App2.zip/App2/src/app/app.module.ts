import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegFormComponent } from './reg-form/reg-form.component';
import { SigninComponent } from './signin/signin.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HomeComponent } from './home/home.component';
import { UpdatecomponentComponent } from './updatecomponent/updatecomponent.component';
import { UsersComponent } from './users/users.component';
import { PrimeuserComponent } from './users/primeuser/primeuser.component';

@NgModule({
  declarations: [
    AppComponent,
    RegFormComponent,
    SigninComponent,
    PagenotfoundComponent,
    HomeComponent,
    UpdatecomponentComponent,
    UsersComponent,
    PrimeuserComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
