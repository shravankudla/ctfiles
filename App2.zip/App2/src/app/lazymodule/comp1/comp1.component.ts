import { Component } from '@angular/core';
import { UserserService } from 'src/app/userser.service';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component {
  userInfo:any

  constructor(private user:UserserService){
    this.user.get().subscribe(udata=>{
      this.userInfo = udata
      console.log(this.userInfo);
    });
  }

  newData = {
    "contactNo": 4,
    "contactName": "string",
    "city": "string",
    "cellNo": "string"
  }

  delete(data:any){
    const stid=data.value.id
    this.user.delet(stid).subscribe(udata=>console.log(udata))
  }
}
