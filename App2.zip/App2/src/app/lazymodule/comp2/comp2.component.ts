import { Component } from '@angular/core';
import { UserserService } from 'src/app/userser.service';

@Component({
  selector: 'app-comp2',
  templateUrl: './comp2.component.html',
  styleUrls: ['./comp2.component.css']
})
export class Comp2Component {
  info:any;
  constructor(private user:UserserService){
    user.getplaceHolderData().subscribe(udata=>{
      this.info=udata
      console.log(this.info)
    })
  }
}
