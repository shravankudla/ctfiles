import { Component } from '@angular/core';
import { UserserService } from '../userser.service';

@Component({
  selector: 'app-reg-form',
  templateUrl: './reg-form.component.html',
  styleUrls: ['./reg-form.component.css']
})
export class RegFormComponent {
  constructor(private user:UserserService){}
  submit(data:any){
    console.log(data.value);
    const studInput={
      "ContactNo":data.value.cno,
      "ContactName":data.value.fname,
      "City":data.value.address,
      "CellNo":data.value.phone
    }
    this.user.add(studInput).subscribe(result=>{
      console.log(result);
    })
    // this.data=data.value;
  }
}
